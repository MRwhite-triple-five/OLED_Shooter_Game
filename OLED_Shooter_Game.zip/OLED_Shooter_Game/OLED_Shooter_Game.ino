#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// Button pins
#define BTN_LEFT  2
#define BTN_RIGHT 3
#define BTN_FIRE  4

int playerX = 60;
const int playerY = 58;

int bulletX = 0;
int bulletY = -10;
bool bulletActive = false;
unsigned long lastShot = 0;
int fireDelay = 500;

const int MAX_ENEMIES = 5;
int enemyX[MAX_ENEMIES];
int enemyY[MAX_ENEMIES];
bool enemyAlive[MAX_ENEMIES];

bool gameOver = false;
int score = 0;
int level = 1;
int enemySpeed = 1;
unsigned long lastLevelUp = 0;

void spawnEnemy(int i) {
  enemyX[i] = random(0, SCREEN_WIDTH - 8);
  enemyY[i] = random(0, 10);
  enemyAlive[i] = true;
}

void resetGame() {
  playerX = 60;
  bulletActive = false;
  score = 0;
  level = 1;
  enemySpeed = 1;
  fireDelay = 500;
  gameOver = false;
  lastLevelUp = millis();
  lastShot = millis();

  for (int i = 0; i < MAX_ENEMIES; i++) {
    spawnEnemy(i);
  }

  display.clearDisplay();
  display.display();
}

void setup() {
  pinMode(BTN_LEFT, INPUT_PULLUP);
  pinMode(BTN_RIGHT, INPUT_PULLUP);
  pinMode(BTN_FIRE, INPUT_PULLUP);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    while (true);
  }

  resetGame();
}

void drawPlayer(int x, int y) {
  display.fillTriangle(x+4, y, x, y+5, x+8, y+5, SSD1306_WHITE);
  display.drawLine(x, y+5, x+8, y+5, SSD1306_WHITE);
}

void drawEnemy(int x, int y) {
  display.drawCircle(x+4, y+4, 4, SSD1306_WHITE);
  display.drawLine(x, y+4, x+8, y+4, SSD1306_WHITE);
}

void explosion(int x, int y) {
  display.drawLine(x, y, x+4, y+4, SSD1306_WHITE);
  display.drawLine(x+4, y, x, y+4, SSD1306_WHITE);
  display.display();
  delay(50);
}

void loop() {
  if (gameOver) {
    display.clearDisplay();
    display.setTextSize(2);
    display.setCursor(10, 20);
    display.print("Yamete");
    display.setTextSize(1);
    display.setCursor(25, 38);
    display.print("Kudasai...");

    display.setCursor(10, 50);
    display.print("Score: ");
    display.print(score);
    display.setCursor(80, 50);
    display.print("Lvl: ");
    display.print(level);
    display.display();

    if (digitalRead(BTN_FIRE) == LOW) {
      delay(500);
      resetGame();
    }
    return;
  }

  if (digitalRead(BTN_LEFT) == LOW && playerX > 0) playerX -= 2;
  if (digitalRead(BTN_RIGHT) == LOW && playerX < SCREEN_WIDTH - 8) playerX += 2;

  if (digitalRead(BTN_FIRE) == LOW && !bulletActive && millis() - lastShot > fireDelay) {
    bulletX = playerX + 3;
    bulletY = playerY - 4;
    bulletActive = true;
    lastShot = millis();
  }

  if (bulletActive) {
    bulletY -= 6;
    if (bulletY < 0) bulletActive = false;
  }

  if (score > 0 && score % 10 == 0 && millis() - lastLevelUp > 2000) {
    level++;
    if (enemySpeed < 5) enemySpeed++;
    if (fireDelay > 150) fireDelay -= 50;
    lastLevelUp = millis();
  }

  for (int i = 0; i < MAX_ENEMIES; i++) {
    if (enemyAlive[i]) {
      enemyY[i] += enemySpeed;

      if (enemyY[i] + 8 >= playerY &&
          enemyX[i] + 8 >= playerX &&
          enemyX[i] <= playerX + 8) {
        gameOver = true;
        return;
      }

      if (enemyY[i] > SCREEN_HEIGHT) {
        spawnEnemy(i);
      }

      if (bulletActive &&
          bulletX >= enemyX[i] &&
          bulletX <= enemyX[i] + 8 &&
          bulletY >= enemyY[i] &&
          bulletY <= enemyY[i] + 8) {
        enemyAlive[i] = false;
        bulletActive = false;
        score++;
        explosion(enemyX[i], enemyY[i]);
        spawnEnemy(i);
      }
    }
  }

  display.clearDisplay();
  drawPlayer(playerX, playerY);

  if (bulletActive) {
    display.fillRect(bulletX, bulletY, 2, 4, SSD1306_WHITE);
  }

  for (int i = 0; i < MAX_ENEMIES; i++) {
    if (enemyAlive[i]) {
      drawEnemy(enemyX[i], enemyY[i]);
    }
  }

  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print("Score:");
  display.print(score);
  display.setCursor(80, 0);
  display.print("Lvl:");
  display.print(level);

  display.display();
  delay(30);
}
